{*
 * wallee Prestashop
 *
 * This Prestashop module enables to process payments with wallee (https://www.wallee.com).
 *
 * @author customweb GmbH (http://www.customweb.com/)
 * @copyright 2017 - 2026 customweb GmbH
 * @license http://www.apache.org/licenses/LICENSE-2.0 Apache Software License (ASL 2.0)
*}
<div class="alert alert-info">
<img src="../modules/wallee/logo.png" style="float:left; margin-right:15px;" height="50">
<p><strong>{l s='This module requires an %s account.' sprintf='wallee' mod='wallee'}</strong></p>
<p><a class="btn btn-default" href="https://app-wallee.com/user/signup" target="_blank">{l s='Sign Up' mod='wallee'}</a> <a class="btn btn-default" href="@WalleeDocPath(docs/en/documentation.html)" target="_blank">{l s='Documentation' mod='wallee'}</a></p>
</div>